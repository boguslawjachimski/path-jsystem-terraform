# handler.py
def lambda_handler(event, context):
    return 'Hello World!'