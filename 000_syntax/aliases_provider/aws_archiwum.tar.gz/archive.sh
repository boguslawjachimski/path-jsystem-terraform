#!/bin/bash
# Skrypt tworzy archiwum z kodem źródłowym
tar cvfz archiwum.tar.gz --exclude='*.auto.tfvars' *